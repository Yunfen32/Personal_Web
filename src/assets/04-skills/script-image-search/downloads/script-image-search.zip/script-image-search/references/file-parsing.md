# 剧本文档解析指南（.docx 与 .pdf）

## 概述

本指南说明如何从 .docx 和 .pdf 两种格式的剧本文档中提取完整的文本内容。

---

## 一、.docx 文件解析

### 方法一：直接使用 Read 工具（推荐首选）

系统内置的 `Read` 工具支持直接读取 .docx 文件，返回格式化文本。
优先使用此方法，因为它无需额外依赖。

```
Read({ file_path: "/path/to/script.docx" })
```

若返回内容完整且结构清晰，直接进入 AI 提取步骤。

### 方法二：Python 脚本解析（备用方案）

如果 Read 工具返回的内容丢失了表格、文本框、页眉页脚等重要信息，
使用以下 Python 脚本进行更精细的解析。

#### 环境要求

- Python 3.13+（系统已安装）
- python-docx 库

#### 安装依赖

```bash
pip install python-docx
```

若 pip 不可用，尝试：
```bash
python -m pip install python-docx
```

#### 解析脚本

```python
"""剧本 .docx 文件文本提取脚本"""
import sys
from docx import Document

def extract_script_text(filepath: str) -> dict:
    """
    提取 .docx 剧本文件的全部文本内容。

    返回结构:
    {
        "paragraphs": [str, ...],
        "tables": [[[str, ...], ...], ...],
        "full_text": str
    }
    """
    doc = Document(filepath)

    paragraphs = []
    for para in doc.paragraphs:
        text = para.text.strip()
        if text:
            paragraphs.append(text)

    tables = []
    for table in doc.tables:
        table_data = []
        for row in table.rows:
            row_data = [cell.text.strip() for cell in row.cells]
            table_data.append(row_data)
        tables.append(table_data)

    full_parts = paragraphs.copy()
    for table in tables:
        for row in table:
            full_parts.append(" | ".join(row))

    full_text = "\n\n".join(full_parts)

    return {
        "paragraphs": paragraphs,
        "tables": tables,
        "full_text": full_text
    }

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法: python extract_script.py <剧本文件路径>")
        sys.exit(1)

    result = extract_script_text(sys.argv[1])
    print(result["full_text"])
```

#### 执行方式

```bash
python extract_script.py "C:/Users/xxx/剧本.docx"
```

---

## 二、.pdf 文件解析

### 方法一：直接使用 Read 工具（推荐首选）

系统内置的 `Read` 工具支持直接读取 PDF 文件，自动提取文本内容。

```
Read({ file_path: "/path/to/script.pdf" })
```

若返回内容完整，直接进入 AI 提取步骤。

### 方法二：Python 脚本解析（备用方案）

如果 Read 工具返回的内容不全、乱码或格式混乱，使用以下 Python 脚本解析。

#### 方案 A：pypdf（轻量级，推荐）

##### 安装

```bash
pip install pypdf
```

##### 解析脚本

```python
"""剧本 .pdf 文件文本提取脚本（pypdf）"""
import sys
from pypdf import PdfReader

def extract_pdf_text(filepath: str) -> str:
    reader = PdfReader(filepath)
    full_text = []
    for i, page in enumerate(reader.pages):
        text = page.extract_text()
        if text and text.strip():
            full_text.append(text.strip())
    return "\n\n".join(full_text)

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法: python extract_pdf.py <剧本文件路径>")
        sys.exit(1)
    print(extract_pdf_text(sys.argv[1]))
```

#### 方案 B：pdfplumber（高级，保留表格和布局）

##### 安装

```bash
pip install pdfplumber
```

##### 解析脚本

```python
"""剧本 .pdf 文件文本提取脚本（pdfplumber）"""
import sys
import pdfplumber

def extract_pdf_text(filepath: str) -> str:
    full_text = []
    with pdfplumber.open(filepath) as pdf:
        for page in pdf.pages:
            # 提取文本
            text = page.extract_text()
            if text:
                full_text.append(text)
            # 提取表格
            tables = page.extract_tables()
            for table in tables:
                for row in table:
                    full_text.append(" | ".join([c or "" for c in row]))
    return "\n\n".join(full_text)

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法: python extract_pdf.py <剧本文件路径>")
        sys.exit(1)
    print(extract_pdf_text(sys.argv[1]))
```

#### 执行方式

```bash
# pypdf 方案
python extract_pdf.py "C:/Users/xxx/剧本.pdf"

# pdfplumber 方案（保留表格）
python extract_pdf_plumber.py "C:/Users/xxx/剧本.pdf"
```

---

## 三、中文剧本解析通用注意事项

1. **编码问题**：python-docx 和 PDF 库默认使用 UTF-8，中文内容一般不会出现乱码。

2. **特殊格式**：剧本常包含"场次标记"（如"第X场"、"日内/夜外"等），
   这些标记对于场景提取很重要，需完整保留。

3. **角色对话格式**：典型中文剧本格式为"角色名：（台词内容）"或
   "角色名\n（台词内容）"。AI 提取时需识别此格式以区分描述性文本和对话内容。

4. **.docx 批注和修订**：python-docx 默认读取接受所有修订后的文本。

5. **.pdf 扫描件**：若 PDF 为扫描图片，需先用 OCR 工具处理，
   可在首次解析失败时提示用户。

6. **.pdf 分栏布局**：多栏排版的 PDF 可能导致提取顺序混乱，
   此时用 pdfplumber 比 pypdf 效果更好。
