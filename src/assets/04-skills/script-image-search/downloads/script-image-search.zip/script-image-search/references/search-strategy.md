# 欧美真人图片搜索策略详细指南

## 搜索工具说明

本技能使用 `WebSearch` 工具进行所有图片搜索。

### WebSearch 参数说明

| 参数 | 说明 | 示例 |
|------|------|------|
| query | 搜索关键词（必填） | `"stadium locker room film photography"` |
| allowed_domains | 限定搜索域名（可选） | `["gettyimages.com", "shot.cafe"]` |
| blocked_domains | 排除域名（可选） | `["shutterstock.com"]` |

---

## 素材风格限定

**仅搜索欧美真人风格素材：**

| ✅ 允许 | ❌ 禁止 |
|--------|--------|
| 摄影（photography） | 概念艺术（concept art） |
| 剧照（film still） | 插画（illustration） |
| 实景照（real location photo） | 动漫（anime/manga） |
| 幕后照（behind the scenes） | 3D渲染（3D render） |
| 编辑部摄影（editorial photo） | 数字绘画（digital painting） |
| 商业摄影（stock photo） | 矢量图（vector art） |

---

## 真实人物/场景处理规则

### 识别标准

剧本中出现以下情况视为"真实元素"：
- **真实人物**：使用真实世界存在的人名（如 Neymar、Tom Brady、Serena Williams）
- **真实地点**：使用真实世界存在的地名/建筑名（如 Maracana Stadium、Wembley、Old Trafford）
- **真实事件**：引用真实发生的历史/新闻事件（如 2022 World Cup Final）

### 处理流程

```
识别为真实元素
    │
    ▼
┌─────────────────────────────────┐
│ 1. 抽象化描述                    │
│    人名/地名 → 类型化描述         │
│    例: Neymar → "Brazilian        │
│    soccer forward, athletic       │
│    build, short dark hair"        │
└──────────┬──────────────────────┘
           │
           ▼
┌─────────────────────────────────┐
│ 2. 搜索 1 个真实链接 🎬          │
│    关键词: "{真实名称} portrait   │
│    photography editorial"         │
│    平台: Getty Images / Alamy     │
└──────────┬──────────────────────┘
           │
           ▼
┌─────────────────────────────────┐
│ 3. 搜索 N-1 个抽象链接 🔍       │
│    关键词: "{抽象描述} film       │
│    still photography"             │
│    平台: Shutterstock / iStock /  │
│    SHOT.CAFE / StillsLab          │
└─────────────────────────────────┘
```

### 链接数量对照表

| 搜索模式 | 🎬 真实链接 | 🔍 抽象链接 | 总计 |
|---------|-----------|-----------|------|
| 搜全部（真实项） | 1 | 2~4 | 3~5 |
| 搜全部（抽象项） | 0 | 3~5 | 3~5 |
| 指定搜索（真实项） | 1 | 9 | 10 |
| 指定搜索（抽象项） | 0 | 10 | 10 |

---

## 搜索流程总览

```
用户剧本
    │
    ▼
┌─────────────────────────────┐
│ Step 2: AI 提取             │
│ - 世界观设定（场景列表）     │
│ - 人物形象（角色列表）       │
│ - 标注 🎬 真实 / 🔍 抽象    │
└──────────┬──────────────────┘
           │
           ▼
   ┌───────┴───────┐
   │               │
   ▼               ▼
┌──────┐     ┌──────────┐
│第一轮│     │ 第二轮    │
│通用  │ ──► │ 平台定向  │
│搜索  │     │ 搜索      │
│摄影  │     │ 剧照/实景  │
└──────┘     └──────────┘
   │               │
   └───────┬───────┘
           ▼
┌─────────────────────────────┐
│ 去重、筛选、排序             │
│ 仅保留欧美真人风格素材       │
└─────────────────────────────┘
```

---

## 第一轮：通用摄影素材搜索

### 场景搜索查询模板

| 场景类型 | 英文查询模板（优先） | 中文辅助查询 |
|----------|-------------------|-------------|
| 体育赛场 | `"{scene}" stadium match photography editorial` | `{场景} 体育场 摄影 剧照` |
| 都市街景 | `"{scene}" city street cinematography film still` | `{场景} 城市街景 电影画面` |
| 室内空间 | `"{scene}" interior set design movie reference` | `{场景} 室内场景 影视参考` |
| 科幻场景 | `"{scene}" sci-fi film set production still` | `{场景} 科幻片场 幕后照` |
| 剧情场景 | `"{scene}" drama film cinematography reference` | `{场景} 电影摄影 参考` |
| 医院/病房 | `"{scene}" hospital room film photography` | `{场景} 医院 影视剧照` |
| 发布会/会议 | `"{scene}" press conference editorial photography` | `{场景} 发布会 新闻摄影` |

### 人物搜索查询模板

| 角色类型 | 英文查询模板（优先） | 中文辅助查询 |
|----------|-------------------|-------------|
| 运动员 | `"{type}" athlete portrait editorial photography` | `{类型} 运动员 写真 摄影` |
| 商人/官员 | `"{type}" businessman suit portrait stock photo` | `{类型} 商务人士 摄影` |
| 教练/权威 | `"{type}" coach authority figure film still` | `{类型} 教练 影视剧照` |
| 反派/对手 | `"{type}" villain antagonist character film reference` | `{类型} 反派角色 电影参考` |
| 病患/弱势 | `"{type}" patient hospital bed film cinematography` | `{类型} 病患 电影摄影` |

---

## 第二轮：摄影/剧照平台定向搜索

### 平台选择策略

按场景类型自动调整平台优先级：

| 场景类型 | 优先级顺序 | 原因 |
|----------|-----------|------|
| 体育赛事 | Getty Images > Alamy > Shutterstock > SHOT.CAFE | Getty/Alamy 体育摄影资源最丰富 |
| 都市/室内 | Shutterstock > iStock > StillsLab > Getty Images | 商业摄影库存量大 |
| 科幻/特效 | SHOT.CAFE > StillsLab > Getty Images | 电影剧照数据库更精准 |
| 真实地标 | Alamy > Getty Images > Shutterstock | Alamy 纪实摄影库强大 |
| 剧情/人物 | SHOT.CAFE > StillsLab > Getty Images > iStock | 影视剧照最有参考价值 |
| 时尚/服饰 | iStock > Shutterstock > Pinterest | 商业摄影+穿搭参考 |

### 各平台搜索参数

#### Getty Images (gettyimages.com)

```
WebSearch({
  query: "{scene/character} editorial photography",
  allowed_domains: ["gettyimages.com"]
})
```

- 优势：全球最大新闻/体育/娱乐摄影库
- 最佳用于：体育赛事、真实人物、新闻场景

#### Shutterstock (shutterstock.com)

```
WebSearch({
  query: "{scene/character} stock photo",
  allowed_domains: ["shutterstock.com"]
})
```

- 优势：海量商业摄影素材，覆盖全品类
- 最佳用于：都市场景、室内空间、人物肖像

#### SHOT.CAFE (shot.cafe)

```
WebSearch({
  query: "{scene/character} film still",
  allowed_domains: ["shot.cafe"]
})
```

- 优势：可搜索的电影剧照数据库
- 最佳用于：剧情场景参考、角色造型参考

#### StillsLab (stillslab.com)

```
WebSearch({
  query: "{scene/character} movie reference",
  allowed_domains: ["stillslab.com"]
})
```

- 优势：影视剧照数据库，摄影/灯光/构图参考
- 最佳用于：电影级场景和人物参考

#### Alamy (alamy.com)

```
WebSearch({
  query: "{scene/character} real location photo",
  allowed_domains: ["alamy.com"]
})
```

- 优势：纪实/新闻/旅行摄影库
- 最佳用于：真实地标、新闻场景、纪实风格

#### iStock (istockphoto.com)

```
WebSearch({
  query: "{scene/character} photography",
  allowed_domains: ["istockphoto.com"]
})
```

- 优势：高质量商业摄影（Getty 子品牌）
- 最佳用于：人物肖像、商业场景、时尚服饰

#### Pinterest (pinterest.com) — 辅助平台

```
WebSearch({
  query: "{scene/character} film photography reference board",
  allowed_domains: ["pinterest.com"]
})
```

- 注意：仅搜索摄影/剧照类 Board，跳过插画/动漫类 Pin
- 辅助用途，非主搜索平台

---

## 结果筛选标准

### 优先级排序

1. **摄影/剧照** > 幕后照 > 活动照 > 截屏
2. **高清** > 低分辨率
3. **欧美白人/黑人演员** > 亚裔演员（剧本为欧美题材）
4. **权威平台**（Getty, Shutterstock）> 聚合平台 > 社交媒体

### 质量检查要点

- 图片应为真实摄影作品，非插画/动漫/3D渲染
- 场景图应展示完整的环境氛围，而非特写
- 人物图应以角色为主体，面部清晰可辨
- 服饰参考应能看清服装款式和细节

### 真人素材排除规则

搜索结果中如出现以下类型，**跳过不使用**：
- 概念图/概念艺术（concept art）
- 卡通/动漫风格（cartoon/anime style）
- 3D 渲染图（3D render/CGI character）
- 粉丝绘画（fan art）
- AI 生成图（AI-generated）

### 去重策略

1. 按 URL 域名+路径去重
2. 相似图片（同一拍摄角度/同一演员）只保留最佳一张
3. 跨平台相同作品保留来源更权威的链接

---

## 搜索失败的回退策略

### 搜全部模式（目标 3-5 个链接，真实项含 1 个真实链接）

| 问题 | 解决方案 |
|------|---------|
| 抽象关键词无摄影结果 | 换用更通用的描述词，如 `"athlete"` 替代 `"Brazilian soccer forward"` |
| 定向平台无结果 | 去掉 `allowed_domains` 限制，放宽搜索范围 |
| 仍无结果 | 使用 `WebFetch` 直接访问 SHOT.CAFE 搜索页面 |
| 所有策略均失败 | 标注"未找到匹配参考图"，跳至下一项 |

### 指定搜索模式（目标 10 个链接）

若两轮搜索后不足 10 个，执行额外回退轮次：

| 轮次 | 策略 | 说明 |
|------|------|------|
| 第三轮 | 去掉 `allowed_domains`，用通用词+摄影词搜索 | `"{type} photography hd"` |
| 第四轮 | 搜索相关近义词 | `"locker room"` → `"changing room interior photography"` |
| 第五轮 | 使用 `WebFetch` 直接访问 SHOT.CAFE/StillsLab | 站内浏览搜索 |
| 全部失败 | 标注实际获取数量 | 诚实告知部分结果 |

---

## 搜索频率控制

1. 每轮搜索之间间隔 2-3 秒
2. 同一平台搜索之间间隔 5 秒以上
3. 单次对话中总搜索次数建议控制在 30 次以内
4. 若剧本场景过多（>10个），分批处理，每批 5 个场景
