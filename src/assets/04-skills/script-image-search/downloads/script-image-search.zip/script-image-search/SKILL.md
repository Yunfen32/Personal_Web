---
name: script-image-search
description: >
  从欧美真人题材剧本文档(.docx/.pdf)中提取世界观设定与人物形象描述，
  自动搜索欧美真人风格的场景和人物参考图片（摄影、剧照、实景）。
  当用户上传剧本文件、需要为剧本寻找视觉参考素材时触发。
  自动识别真实人物/场景并抽象后搜索，真实链接仅保留1个。
  支持提取后由用户选择：搜全部（每项3-5个链接）或
  指定单个/多个场景人物（每项10个链接），附带Markdown汇总表格。
---

# 剧本图片搜索 (Script Image Search)

## 概述

本技能从用户提供的 .docx 或 .pdf 剧本文档中，自动提取世界观设定和人物形象描述，
并通过多轮搜索策略（通用搜索引擎 + 摄影/剧照素材网站定向搜索），为选定的场景和人物
查找视觉参考图片链接。

**剧本默认类型：欧美真人题材**（现代体育、传记、剧情、犯罪等真人电影/剧集风格）。

**两种搜索模式：**
- **搜全部**：每个场景/人物返回 3-5 个链接（真实项 1 真人 + 其余抽象参考）
- **指定搜索**：用户手动勾选，每项返回 10 个链接（真实项 1 真人 + 9 抽象参考）

## 前置准备

### 依赖检查

技能首次运行时，自动检查并安装所需 Python 依赖：

```bash
# .docx 解析
pip install python-docx

# .pdf 解析
pip install pypdf pdfplumber
```

### 输入要求

- 用户提供 .docx 或 .pdf 格式的剧本文档路径
- 文档应包含完整的剧本内容（场景描述、人物对话等）
- 默认为欧美真人题材

## 工作流程

### Step 1: 读取并解析剧本文档

#### 自动识别文件类型

根据文件扩展名自动选择解析方式：

**情况 A：.docx 文件**

1. **首选方案**：使用 `Read` 工具直接读取 .docx 文件。
   系统原生支持 .docx 读取，直接传入文件路径即可获取文本内容。

2. **备用方案（Python 解析）**：若 Read 工具返回内容不够结构化
   （如表格、分栏内容丢失），使用 python-docx 做二次解析。
   详见 `references/file-parsing.md` 获取完整的 Python 解析脚本。

**情况 B：.pdf 文件**

1. **首选方案**：使用 `Read` 工具直接读取 .pdf 文件。
   系统原生支持 PDF 读取，自动提取文本和视觉内容。

2. **备用方案（Python 解析）**：若 Read 工具返回内容不全或乱码，
   使用 pypdf 或 pdfplumber 做二次解析。
   详见 `references/file-parsing.md` 获取 PDF 解析脚本。

3. 将提取的全文保存为上下文，用于后续 AI 分析。

**校验点：** 确认已成功获取剧本全文，文本长度 > 0。若失败，提示用户检查文件路径和格式。

### Step 2: AI 提取世界观设定和人物描述

1. 将 Step 1 获取的剧本全文提交给 AI 进行分析。

2. 使用两套结构化提示词（详见 `references/extraction-prompts.md`）：
   - **世界观提取**：时代背景、地理环境、建筑风格、气候氛围、关键场景元素
   - **人物提取**：姓名、年龄、性别、外貌特征、服饰风格、气质描述、特殊标记
   - **真人元素识别**：标注哪些人物/场景对应真实存在的人或地点

3. AI 输出结构化数据格式（每个场景和人物标注是否为真实元素）：

```
## 世界观设定
- 时代背景: xxx
- 地理环境: xxx
- 关键场景1: xxx (描述) [抽象/真实: xxx]
- 关键场景2: xxx (描述) [抽象/真实: xxx]
...

## 人物形象
- 人物1: 姓名 | 年龄 | 性别 | 外貌描述 | 服饰风格 | 气质 [抽象/真实: xxx]
- 人物2: ...
```

4. **真人元素处理规则（核心）**：

   对于标注为**真实**的人物或场景，执行以下处理：

   a. **抽象化描述**：将真实人名/地名替换为类型化描述。
      - 例：Neymar → "Brazilian soccer forward, athletic build, short dark hair, intense eyes"
      - 例：Maracana Stadium → "massive football stadium, bowl-shaped arena, floodlights, packed crowd"

   b. **链接数量规则**：
      - **搜全部模式**：1 个真实参考链接（官方照/实景照） + 2~4 个抽象参考链接
      - **指定搜索模式**：1 个真实参考链接（官方照/实景照） + 9 个抽象参考链接
      - 真实链接标注为 🎬 真实参考，抽象链接标注为 🔍 类型参考

   c. **真实链接策略**：仅搜索 1 次获取该真实人物/地点的高质量参考照，
      不对此链接做多轮扩展搜索。剩余链接全部用抽象描述搜索。

   d. **抽象链接策略**：用抽象化后的类型描述搜索欧美真人风格素材。

5. **与用户交互选择**：展示提取结果后，使用 `AskUserQuestion` 让用户选择搜索范围：

   **第一问：搜索范围**
   - "搜全部" — 搜索所有场景和人物（每项 3-5 个链接）
   - "只搜场景" — 仅搜索场景图片（每项 3-5 个链接）
   - "只搜人物" — 仅搜索人物图片（每项 3-5 个链接）
   - "指定搜索" — 手动选择要搜的具体场景/人物

   若用户选择"指定搜索"，则继续：
   **第二问：选择具体项（多选，场景和人物可各选任意个）**
   - 用一个 `AskUserQuestion` 同时列出场景编号+名称和人物编号+名称
   - 用户可任意组合多选
   - 被选中的项每项返回 10 个链接
   - **仅搜索被选中的项**，未选中的不搜索

6. 若提取失败，请用户手动提供关键场景和人物列表，再进入选择流程。

**校验点：** 确保每个场景元素和人物都有足够的视觉关键词用于图片搜索。真实元素已正确标注。

### Step 3: 搜索场景图片 — 欧美真人策略

针对每个世界观/场景元素，执行**双轮搜索策略**：

#### 前置：判断是否为真实场景

- **真实场景**：先搜索 1 个真实地点照（如 "Maracana Stadium aerial photography"），
  标记为 🎬 真实参考。剩余链接全部用抽象描述搜索。
- **抽象场景**：全部用类型化描述搜索欧美真人风格素材。

#### 第一轮：摄影素材搜索引擎搜索

使用 `WebSearch` 工具，查询策略：

- **英文关键词（优先）**：`{scene_description} film photography behind the scenes`
- **中文辅助关键词**：`{场景描述} 电影剧照 摄影参考`
- 根据风格添加特定关键词：
  - 体育：`{scene} stadium match photography editorial`
  - 都市：`{scene} city street cinematography film still`
  - 室内：`{scene} interior set design movie reference`
  - 科幻：`{scene} sci-fi film set production still`
  - 剧情：`{scene} drama film cinematography reference`

#### 第二轮：摄影/剧照平台定向搜索

使用 `WebSearch` 配合 `allowed_domains` 参数，定向搜索：

| 平台 | 域名 | 适用场景 | 搜索关键词示例 |
|------|------|----------|---------------|
| Getty Images | gettyimages.com | 摄影素材（全品类） | `{scene} editorial photography` |
| Shutterstock | shutterstock.com | 商业摄影素材 | `{scene} stock photo` |
| SHOT.CAFE | shot.cafe | 电影剧照搜索 | `{scene} film still` |
| StillsLab | stillslab.com | 影视剧照参考 | `{scene} movie reference` |
| Alamy | alamy.com | 新闻/纪实摄影 | `{scene} real location photo` |
| iStock | istockphoto.com | 高质量摄影素材 | `{scene} photography` |

**平台选择优先级**（根据场景类型自动调整）：

| 场景类型 | 优先级顺序 |
|----------|-----------|
| 体育赛事 | Getty Images > Alamy > Shutterstock > SHOT.CAFE |
| 都市/室内 | Shutterstock > iStock > StillsLab > Getty Images |
| 科幻/特效场景 | SHOT.CAFE > StillsLab > Getty Images |
| 真实地标/建筑 | Alamy > Getty Images > Shutterstock |
| 剧情场景 | SHOT.CAFE > StillsLab > Getty Images > Shutterstock |

#### 链接筛选

1. 去重：移除重复图片链接
2. 优先选择摄影/剧照类素材，避免插画/概念艺术/动漫风格
3. 若搜索结果不足，放宽关键词重新搜索
4. **搜全部模式**：真实场景 = 1 真实 + 2~4 抽象；抽象场景 = 3-5 个链接
5. **指定搜索模式**：真实场景 = 1 真实 + 9 抽象；抽象场景 = 10 个链接

**校验点：** 所有链接均为欧美真人风格（摄影/剧照/实景），无概念艺术/动漫。

### Step 4: 搜索人物图片 — 欧美真人策略

与 Step 3 类似策略，使用人物导向关键词：

#### 前置：判断是否为真实人物

- **真实人物**：先搜索 1 个真人参考照（如 "Neymar portrait photography"、
  "Neymar match action photo"），标记为 🎬 真实参考。剩余链接全部用抽象描述搜索。
- **抽象人物**：全部用类型化描述搜索欧美真人风格素材。

#### 摄影素材搜索引擎搜索

- **英文（优先）**：`{character_type} actor headshot portrait photography`
- **中文辅助**：`{角色类型} 欧美演员 定妆照 摄影参考`
- 附加风格词：`casting photo`、`character portrait`、`wardrobe reference`、`behind the scenes`

#### 摄影/剧照平台定向搜索

| 平台 | 搜索关键词示例 |
|------|---------------|
| Getty Images | `{character_type} portrait editorial photography` |
| Shutterstock | `{character_type} model stock photo` |
| SHOT.CAFE | `{character_type} film character reference` |
| StillsLab | `{character_type} movie still` |
| iStock | `{character_type} actor portrait photography` |
| Pinterest | `{character_type} film character wardrobe reference` |

#### 链接筛选与验证

同 Step 3 的筛选规则。额外要求：
- 所有抽象人物链接必须为摄影/剧照风格，非插画/动漫
- 真实人物链接选用高质量官方照或权威媒体摄影

**校验点：** 所有链接均为欧美真人风格。

### Step 5: 整理并输出结果

按以下格式组织输出（先链接列表，后汇总表格）。链接按"真实参考 → 抽象参考"排列：

```
## 场景参考图片

### {场景名称} 🎬 真实场景
> 原剧描述: {剧本中的相关描述}
> 抽象描述: {抽象化后的类型描述}
> 搜索模式: 指定搜索 | 🎬 真实参考 1个 + 🔍 类型参考 9个

1. 🎬 [真实链接1](url) - 来源: Getty Images
2. 🔍 [抽象链接1](url) - 来源: Shutterstock
...
10. 🔍 [抽象链接9](url) - 来源: StillsLab

### {场景名称} 🔍 抽象场景
> 原剧描述: {剧本中的相关描述}
> 搜索模式: 搜全部 | 共4个参考链接

1. 🔍 [链接1](url) - 来源: Getty Images
...
4. 🔍 [链接4](url) - 来源: StillsLab

---

## 人物参考图片

### {人物姓名} 🎬 真实人物
> 原剧描述: {人物外貌描述}
> 抽象描述: {抽象化后的类型描述}
> 搜索模式: 搜全部 | 🎬 真实参考 1个 + 🔍 类型参考 3个

1. 🎬 [真实链接1](url) - 来源: Getty Images
2. 🔍 [抽象链接1](url) - 来源: Shutterstock
3. 🔍 [抽象链接2](url) - 来源: iStock
4. 🔍 [抽象链接3](url) - 来源: SHOT.CAFE

---

## 汇总表格

| 类型 | 名称 | 描述概要 | 真实/抽象 | 搜索模式 | 🎬真实 | 🔍抽象 | 主要来源 |
|------|------|---------|----------|---------|-------|-------|---------|
| 场景 | xxx  | xxx     | 🎬 真实   | 搜全部   | 1     | 3     | Getty, Shutterstock |
| 场景 | xxx  | xxx     | 🔍 抽象   | 指定搜索 | -     | 10    | SHOT.CAFE, iStock |
| 人物 | xxx  | xxx     | 🎬 真实   | 搜全部   | 1     | 4     | Getty, StillsLab |
| 人物 | xxx  | xxx     | 🔍 抽象   | 搜全部   | -     | 5     | Shutterstock, iStock |
```

## 分批策略

- **搜全部模式**：若场景+人物总数 ≤ 10 个一次性处理，> 10 个每批 5 个
- **指定搜索模式**：每项搜索量较大（10 个链接），每次处理 1-2 项，批次间暂停 5 秒
- 真实元素先搜索 1 个真实链接，再用抽象描述搜索其余链接

## 素材风格要求（全局）

- **仅使用欧美真人风格**：摄影（photography）、剧照（film still）、实景照（real location photo）、幕后照（behind the scenes）
- **禁止**：概念艺术（concept art）、插画（illustration）、动漫（anime/manga）、3D渲染（3D render）
- 如搜索结果中出现非真人风格素材，跳过并继续搜索

## 错误处理

- **文件无法读取**：提示用户检查文件路径和格式，确认是 .docx 或 .pdf 文件
- **python-docx 或 pypdf 安装失败**：尝试替代安装方式，或回退仅使用 Read 工具
- **无法提取设定**：请用户手动提供关键场景和人物列表
- **搜索无结果**：尝试放宽关键词 → 更换搜索平台 → 使用近义词 → 使用 WebFetch 直接访问素材网站
- **链接失效**：优先使用平台官方链接而非直链，提高稳定性
- **真实人物确认**：若无法确定某人物/场景是否真实存在，标注为"疑似真实"并请用户确认

## 参考文档

- `references/file-parsing.md` - .docx 和 .pdf 文件解析详细指南和 Python 脚本
- `references/extraction-prompts.md` - AI 提取世界观、人物和真人元素识别的提示词模板
- `references/search-strategy.md` - 欧美真人风格图片搜索策略、平台选择和关键词模板
